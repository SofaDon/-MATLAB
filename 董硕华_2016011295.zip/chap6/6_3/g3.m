function y = g3(x)
y = x^2;
end