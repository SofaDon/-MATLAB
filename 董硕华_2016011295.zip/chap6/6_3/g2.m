function [y] = g2(x)
y = x;
end
