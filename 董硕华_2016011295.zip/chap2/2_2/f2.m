%function 2
function [y] = f2(x)
y = -x^3 + 5 * x;
end